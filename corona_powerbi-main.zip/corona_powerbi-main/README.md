# HR ANALYSIS

# Description
              As you know, Coronavirus is a pandemic disease. It is spreading in almost every country, and people are locked down in their houses. Recently, India entered in 21 days total lockdown due to an increase in Coronavirus cases.


# DEVOPS 


https://dev.azure.com/vanshverma3108/HR%20analytics/_git/HR%20analytics

 # HR ANALYTICS USING POWERBI
![coronavirus5](https://user-images.githubusercontent.com/126977380/228224599-27d371ee-05e8-4255-a671-9a58fe2ce12d.png)
![coronavirus4](https://user-images.githubusercontent.com/126977380/228224614-66145a75-fb0c-4c44-8f41-923e1246d8dd.png)
![coronavirus3](https://user-images.githubusercontent.com/126977380/228224637-ad65975d-1c34-40d0-9cb1-b6e82b332326.png)
![coronavirus2](https://user-images.githubusercontent.com/126977380/228224650-e3d034ab-4c44-4ebb-9590-b02c3e018077.png)
![coronavirus1](https://user-images.githubusercontent.com/126977380/228224664-916ae86b-643a-443f-8c10-c8def9f25b9e.png)

# Deployment 


I have used power bi as well as dev ops to deploy this project , first i used my power bi for the project after that , when the project is dont i have used dev ops to connect my github repo such that i can deploy this on the open web , hence i have used 2 of the azure technologies that the future ready talent requires.


![Screenshot (874)](https://user-images.githubusercontent.com/126977380/228234742-3908e416-f0c4-4363-b2b5-ca01c3f7ab4c.png)

# Project link
https://drive.google.com/file/d/1A8dI5zFYqaOCwFnAyp6yJZsRqgOlzbGF/view?usp=share_link

# Project information
https://drive.google.com/file/d/1iXnuDoD0I8o7OxZgTJYkmaSe_8_L4Izy/view?usp=share_link
